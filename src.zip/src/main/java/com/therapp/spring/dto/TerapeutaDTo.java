package com.therapp.spring.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class TerapeutaDTo {
    private Long usuarioId;
    private String NColegiado;
    private String especialidad;
    
}
