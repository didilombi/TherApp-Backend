package com.therapp.spring.modelo;

public enum RolPublicacion {
    AUTOR,
    COLABORADOR
}
