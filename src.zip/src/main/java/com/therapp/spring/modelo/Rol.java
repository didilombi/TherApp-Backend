package com.therapp.spring.modelo;

public enum Rol {
	USUARIO,
	TERAPEUTA,
    ORGANIZACION,
 	ADMIN
}
