package com.therapp.spring.controladores;

public class ContenidoPublicacionController {
    
}
