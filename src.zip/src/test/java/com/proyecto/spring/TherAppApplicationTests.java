package com.proyecto.spring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TherAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
